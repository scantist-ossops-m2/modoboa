.. _stats:

####################
Graphical statistics
####################

`Official documentation <http://modoboa-stats.readthedocs.org>`_.
