#############################
Postfix relay domains support
#############################

`Official documentation <http://modoboa-admin-relaydomains.readthedocs.org>`_.
