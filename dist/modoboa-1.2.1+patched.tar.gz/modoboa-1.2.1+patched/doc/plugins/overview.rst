########
Overview
########

**************************
Enable or disable a plugin
**************************

Modoboa provides an online panel to control plugins activation. You
will find it at *Modoboa > Extensions*. 

To activate a plugin, check the corresponding box and click on the
*Apply* button.

To deactivate a plugin, uncheck the corresponding box and click on the
*Apply* button.
