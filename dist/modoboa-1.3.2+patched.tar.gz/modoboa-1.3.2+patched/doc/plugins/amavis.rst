.. _amavis_frontend:

####################
Amavisd-new frontend
####################

`Official documentation <http://modoboa-amavis.readthedocs.org>`_.
