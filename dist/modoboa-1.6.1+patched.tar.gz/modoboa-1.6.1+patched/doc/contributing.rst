Rules
=================

.. include:: ../CONTRIBUTING.rst
