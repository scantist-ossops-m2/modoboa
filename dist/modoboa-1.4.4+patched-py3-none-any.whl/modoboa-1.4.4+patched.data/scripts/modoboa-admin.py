#!python
# coding: utf-8

from modoboa.core.commands import handle_command_line

if __name__ == "__main__":
    handle_command_line()

