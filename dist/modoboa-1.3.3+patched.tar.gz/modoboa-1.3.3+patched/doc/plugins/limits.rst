################
Per-admin limits
################

`Official documentation <http://modoboa-admin-limits.readthedocs.org>`_.
