from __future__ import unicode_literals

default_app_config = "modoboa.relaydomains.apps.RelayDomainsConfig"
