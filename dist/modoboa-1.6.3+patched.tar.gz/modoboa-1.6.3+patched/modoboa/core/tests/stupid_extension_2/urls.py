"""Custom urls."""

urlpatterns = []
