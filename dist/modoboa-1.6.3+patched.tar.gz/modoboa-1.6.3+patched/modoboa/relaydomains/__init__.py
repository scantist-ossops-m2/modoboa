default_app_config = "modoboa.relaydomains.apps.RelayDomainsConfig"
