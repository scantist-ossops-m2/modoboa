.. include:: doc/contributing.rst
