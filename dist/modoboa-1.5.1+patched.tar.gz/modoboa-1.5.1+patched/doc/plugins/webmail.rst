.. _webmail:

#######
Webmail
#######

`Official documentation <http://modoboa-webmail.readthedocs.org>`_.
