###################
Tools for migration
###################

******************************
Migrate existing IMAP accounts
******************************

`OfflineIMAP extension <https://github.com/modoboa/modoboa-imap-migration>`_.

************
PostfixAdmin
************

`Official repository <https://github.com/modoboa/modoboa-pfxadmin-migrate>`_.
