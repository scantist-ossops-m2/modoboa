default_app_config = "modoboa.limits.apps.LimitsConfig"
