from django.conf.urls import patterns

urlpatterns = patterns(
    'modoboa.limits.views',

)
